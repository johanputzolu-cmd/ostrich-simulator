# LINUX DATALOG SIM

Standalone Linux package for Honda datalog simulation.

## Included

- `honda_datalog_simulator_gui.py`: visual simulator (GUI)
- `Start-Honda-Datalog-GUI.sh`: launch GUI mode
- `install-deps-ubuntu.sh`: install Ubuntu dependencies
- `requirements.txt`: python package requirements

## Quick start

```bash
cd "$(dirname "$0")"
./Start-Honda-Datalog-GUI.sh
```

## If dependencies are missing (Ubuntu/Debian)

```bash
./install-deps-ubuntu.sh
```

## GUI mode

```bash
./Start-Honda-Datalog-GUI.sh
```

## DATALOG app connection

1. Start GUI mode and click `Start`.
2. Read displayed `/dev/pts/X` port.
3. In Honda Studio DATALOG: `SCAN` -> select that port -> `CONNECT`.
